﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace CMCS.Models
{
    public class CMCSContext : DbContext
    {
        public DbSet<User> Users => Set<User>();
        public DbSet<Claim> Claims => Set<Claim>();
        public DbSet<Document> Documents => Set<Document>();

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseMySql("server=localhost;database=CMCS;user=root;password=yourpassword",
                    ServerVersion.AutoDetect("server=localhost;database=CMCS;user=root;password=yourpassword"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // This is empty for now - we'll add configurations later
        }
    }
}