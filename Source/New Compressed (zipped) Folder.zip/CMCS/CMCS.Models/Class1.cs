﻿namespace CMCS.Models
{
    public class Class1
    {

    }
}
