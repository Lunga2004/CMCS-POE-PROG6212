﻿namespace CMCS.Tests
{
    public class Class1
    {

    }
}
