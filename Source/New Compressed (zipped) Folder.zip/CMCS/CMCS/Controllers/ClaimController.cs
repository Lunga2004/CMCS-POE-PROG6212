﻿using Microsoft.AspNetCore.Mvc;
using CMCS.Models;

namespace CMCS.Controllers
{
    public class ClaimController : Controller
    {
        public IActionResult Submit()
        {
            return View();
        }

        public IActionResult Status()
        {
            return View();
        }
    }
}